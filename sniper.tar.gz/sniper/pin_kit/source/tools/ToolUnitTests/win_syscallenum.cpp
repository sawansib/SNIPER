/*BEGIN_LEGAL 
Intel Open Source License 

Copyright (c) 2002-2014 Intel Corporation. All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.  Redistributions
in binary form must reproduce the above copyright notice, this list of
conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.  Neither the name of
the Intel Corporation nor the names of its contributors may be used to
endorse or promote products derived from this software without
specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE INTEL OR
ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
END_LEGAL */

/* ===================================================================== */
/*
  @ORIGINAL_AUTHOR: Jim Cownie
*/

/* ===================================================================== */
/*! @file
 * Check that we can obtain the windows system call numbers from the 
 * system call keys, and convert back from the number to the key.
 */

#include <iostream>

#include "pin.H"

static KNOB<BOOL> KnobVerbose(KNOB_MODE_WRITEONCE, "pintool",
                              "v", "0", "enable verbose output");

static int checkSyscalls(BOOL verbose)
{
    int successes = 0;

    if (verbose)
    {
        cerr << "Key   Call" << endl;
    }

    for (UINT32 key = SYSCALL_KEY_FIRST; key < SYSCALL_KEY_END; key++)
    {
        UINT32 syscallNumber = PIN_GetWindowsSyscallFromKey (SYSCALL_KEY(key));
        
        if (verbose)
        {
            cerr << decstr(key,3) << "   " << hexstr(syscallNumber,4) << endl;
        }

        // Some system calls are not available on some versions of the OS,
        // e.g.
        //    NtCreateUserProcess is only available on Vista (and later)
        //    NtCreateThreadEx    is only available on Vista (and later)
        if (syscallNumber == SYSCALL_NUMBER_INVALID)
        {
            continue;
        }
        
        SYSCALL_KEY secondKey = PIN_GetKeyFromWindowsSyscall(syscallNumber);

        if (secondKey != key)
        {
            continue;
        }

        successes++;
    }

    return successes;
}

int main(INT32 argc, CHAR *argv[])
{
    PIN_Init(argc, argv);
    
    int successes = checkSyscalls(KnobVerbose);

    cerr << successes << " known system calls found" << endl;
    if (successes == 0)
    {
        exit (1);                               /* Failed to find any, something really is wrong. */
    }
    exit(0);
}
