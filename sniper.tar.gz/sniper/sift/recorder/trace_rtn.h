#ifndef __TRACE_RTN_H
#define __TRACE_RTN_H

#include <pin.H>

void initRoutineTracer();

#endif // __TRACE_RTN_H
