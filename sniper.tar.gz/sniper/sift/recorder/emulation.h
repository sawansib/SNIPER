#ifndef __EMULATION_H
#define __EMULATION_H

void initEmulation();

#endif // __EMULATION_H
