#ifndef __RECORDER_BASE_H
#define __RECORDER_BASE_H

void initRecorderBase();

#endif // __RECORDER_BASE_H
