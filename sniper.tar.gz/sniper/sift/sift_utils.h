#ifndef __SIFT_UTILS_H
#define __SIFT_UTILS_H

#include "sift.h"

namespace Sift
{
   void hexdump(const void * data, uint32_t size);
};

#endif // __SIFT_UTILS_H
